module.exports = (api, options) => {
    console.log('vue cli plugin', api, options)
}