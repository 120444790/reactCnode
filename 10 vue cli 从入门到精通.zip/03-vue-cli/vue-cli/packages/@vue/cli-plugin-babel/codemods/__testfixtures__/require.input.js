const config = {
  presets: [
    [require('@vue/babel-preset-app'), {
      polyfills: []
    }]
  ]
}

module.exports = config
