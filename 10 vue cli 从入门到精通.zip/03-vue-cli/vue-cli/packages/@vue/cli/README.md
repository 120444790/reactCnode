# @vue/cli

``` sh
npm install -g @vue/cli
vue create my-project
```

[Full Docs](https://cli.vuejs.org/)
