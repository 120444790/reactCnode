module.exports = [{
  type: 'confirm',
  name: 'ok',
  message: 'Are you ok?'
}]
