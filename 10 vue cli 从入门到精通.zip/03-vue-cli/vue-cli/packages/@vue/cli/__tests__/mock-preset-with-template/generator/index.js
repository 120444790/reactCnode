module.exports = (api, options) => {
  api.render('./template', options)
}
