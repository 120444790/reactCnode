test.todo('upgrade: should respect plugin resolveFrom')
