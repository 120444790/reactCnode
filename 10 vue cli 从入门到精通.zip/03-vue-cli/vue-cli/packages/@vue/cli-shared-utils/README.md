# @vue/cli-shared-utils

> shared-utils for vue-cli
