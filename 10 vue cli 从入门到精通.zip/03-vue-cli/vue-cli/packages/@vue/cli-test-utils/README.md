# @vue/cli-test-utils

> test-utils for vue-cli
