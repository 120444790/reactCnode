# @vue/cli-service

> service for vue-cli

[Full Docs](https://cli.vuejs.org/)
