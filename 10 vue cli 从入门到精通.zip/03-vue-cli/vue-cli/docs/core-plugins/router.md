# @vue/cli-plugin-router

> router plugin for vue-cli

## Installing in an Already Created Project

``` sh
vue add router
```
