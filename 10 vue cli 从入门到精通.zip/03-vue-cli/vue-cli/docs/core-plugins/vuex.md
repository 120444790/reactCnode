# @vue/cli-plugin-vuex

> vuex plugin for vue-cli

## Installing in an Already Created Project

``` sh
vue add vuex
```
