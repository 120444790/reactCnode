# @vue/cli-plugin-vuex

> Плагин vuex для vue-cli

## Установка в уже созданный проект

```sh
vue add vuex
```
