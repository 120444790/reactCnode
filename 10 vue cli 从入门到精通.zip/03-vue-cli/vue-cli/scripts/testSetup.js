process.env.VUE_CLI_TEST = true
process.env.VUE_CLI_SKIP_DIRTY_GIT_PROMPT = true
