module.exports = {
  assetsDir: 'dist',
  publicPath: '/test'
}