module.exports = function(api, options) {
    console.log('this is vue plugin', api, options)
}