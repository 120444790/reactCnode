import styled from 'styled-components';
import './index.less'
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Link } from 'react-router-dom'
import * as API from '@/api';

import Swiper from 'react-id-swiper';
import 'swiper/css/swiper.css'

const Contaienr = styled.div`
  background-color: #fff;
  height: 3.75em;
`;

const SwiperItemLink = styled(Link)`
  height: 100%;
`;

// import GoodList from '../../components/GoodList/index'

const BannerSwiper = ({ banner = [] }) => {
  const swiperOption = {
    style: {
      height: '100%'
    },
    pagination: {
      el: '.swiper-pagination',
      clickable: true
    },
    autoplay: {
      disableOnInteraction: false, // 用户操作swiper之后，是否禁止autoplay。
      delay: 2000
    },
    loop: true,
    speed: 1000,
    observer: true, //修改swiper自己或子元素时，自动初始化swiper
    observeParents: true //修改swiper的父元素时，自动初始化swiper
  }
  return (
    banner.length > 0 &&
    <div className="slider-banner banner">
      <Swiper {...swiperOption}>
        {
          banner.map((item, index) => (
            <div key={index} >
              <Link style={{height:'100%'}} className="search acea-row row-middle" to={item.wap_url ? item.wap_url : ''}>
                <img src={item.pic} alt="" />
              </Link>
            </div>
          ))
        }
      </Swiper>
    </div>
  )
}

const mapStateToProps = (state, ownProps) => {

  return {
    userInfo: state.userInfo,
    a: state
  }
}
const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    startLoading: () => {
      dispatch({ type: 'LOADING_START' })
    },
    endLoading: () => {
      dispatch({ type: 'LOADING_END' })
    }
  }
}
@connect(mapStateToProps, mapDispatchToProps)
class Home extends Component {
  constructor(props) {
    super(props)
    this.state = {
      showCoupon: false,
      logoUrl: "",
      banner: [],
      menus: [],
      info: {
        fastList: [],
        bastBanner: [],
        firstList: [],
        bastList: []
      },
    }
  }

  render() {

    return (
      <Contaienr className="index">
        {
          this.state.logoUrl && <div className="header acea-row row-center-wrapper">
            <div className="logo">
              <img src={this.state.logoUrl} alt="" />
            </div>
            <Link className="search acea-row row-middle" to="/search">
              <span className="iconfont icon-xiazai5"></span>
              搜索商品
					</Link>
          </div>
        }
        <BannerSwiper banner={this.state.banner}></BannerSwiper>
        <div className="nav acea-row">
          {
            this.state.menus.map((item, index) => (
              <Link className="item" key={index} to={item.wap_url ? item.wap_url : ''}>
                <div className="pictrue">
                  <img src={item.pic} alt="" />
                </div>
                <div style={{ lineHeight: '0.36rem' }}>{item.name}</div>
              </Link>
            ))
          }
        </div>
        {/* <GoodList goodList={this.state.info.bastList} isSort={false}></GoodList> */}
      </Contaienr>
    )
  }
  componentDidMount() {
    this.getHomeData()
  }

  getHomeData() {
    this.props.startLoading()
    API.getHomeData().then(res => {
      this.setState({
        logoUrl: res.data.logoUrl,
        banner: res.data.banner ?? [],
        menus: res.data.menus ?? [],
        info: res.data.info,
      })
      this.props.endLoading()
    })
  }
}

export default Home;
