import React, { Component } from 'react'
import { login, register } from '@/api'
import { connect } from 'react-redux'

import { Toast } from 'antd-mobile'
class Login extends Component {
	constructor(props) {
		super(props)
		this.state = {
			logoUrl: "",
			navList: ["账号登录"],
			current: 0,
			account: "",
			password: "",
			formItem: 1,
			type: "login",
			disabled: false,
		}
  }

	render() {
		return (
			<div className="register absolute">
				<div className="shading">
				</div>
				{
					this.state.formItem === 1 ? <div className="whiteBg">
						<div className="title acea-row row-center-wrapper">
							{
								this.state.navList.map((item, index) => (
									<div className={`item ${this.state.current === index ? 'on' : ''}`} key={index}
										onClick={() => this.navTap(index)}
									>{item}</div>
								))
							}
						</div>
							<div className="list">
								<form onSubmit={this.submitBtn}>
									<div className="item">
										<div className="acea-row row-between-wrapper">
											<svg className="icon" id="icon-phone_" viewBox="0 0 1024 1024"><path d="M765.125 118.25c15.46875 0 28.125 12.65625 28.125 28.125v731.25c0 15.46875-12.65625 28.125-28.125 28.125H258.875c-15.46875 0-28.125-12.65625-28.125-28.125V146.375c0-15.46875 12.65625-28.125 28.125-28.125h506.25m0-56.25H258.875C212.1875 62 174.5 99.6875 174.5 146.375v731.25c0 46.6875 37.6875 84.375 84.375 84.375h506.25c46.6875 0 84.375-37.6875 84.375-84.375V146.375c0-46.6875-37.6875-84.375-84.375-84.375z" fill="#464F66"></path><path d="M793.25 652.625H230.75v56.25h562.5v-56.25z" fill="#464F66"></path><path d="M512 807.3125m-42.1875 0a42.1875 42.1875 0 1 0 84.375 0 42.1875 42.1875 0 1 0-84.375 0Z" fill="#F35749"></path></svg>
											<input
												type="text"
												placeholder="输入账号"
												value={this.state.account}
												onChange={this.accountChange}
												required
											/>
										</div>
									</div>
									<div className="item">
										<div className="acea-row row-between-wrapper">
											<svg className="icon" id="icon-code_" viewBox="0 0 1024 1024"><path d="M793.25 455.75c15.46875 0 28.125 12.65625 28.125 28.125v393.75c0 15.46875-12.65625 28.125-28.125 28.125H202.625c-15.46875 0-28.125-12.65625-28.125-28.125V483.875c0-15.46875 12.65625-28.125 28.125-28.125h590.625m0-56.25H202.625c-46.6875 0-84.375 37.6875-84.375 84.375v393.75c0 46.6875 37.6875 84.375 84.375 84.375h590.625c46.6875 0 84.375-37.6875 84.375-84.375V483.875c0-46.6875-37.6875-84.375-84.375-84.375zM238.90625 346.34375c28.6875-116.4375 133.875-203.0625 259.03125-203.0625s230.34375 86.625 259.03125 203.0625h57.9375C785.09375 198.40625 654.59375 87.03125 497.9375 87.03125S210.5 198.40625 180.96875 346.34375h57.9375z" fill="#464F66"></path><path d="M301.34375 638h85.78125v85.78125H301.34375zM455.1875 638h85.78125v85.78125h-85.78125zM608.75 638h85.78125v85.78125h-85.78125z" fill="#F35749"></path></svg>
											<input
												type="password"
												placeholder="填写登录密码"
												value={this.state.password}
												onChange={this.passwordChange}
												required
											/>
										</div>
									</div>
								</form>
							</div>
						<div className="logon" onClick={this.loginMobile}>登录</div>
						<div className="tip">
							没有账号?
        			<span className="font-color-red" onClick={() => { this.setState({ formItem: 2 }) }}>立即注册</span>
						</div>
					</div> :
						<div className="whiteBg">
							<div className="title">注册账号</div>
							<div className="list">
								<div className="item">
									<div>
										<svg className="icon" id="icon-phone_" viewBox="0 0 1024 1024"><path d="M765.125 118.25c15.46875 0 28.125 12.65625 28.125 28.125v731.25c0 15.46875-12.65625 28.125-28.125 28.125H258.875c-15.46875 0-28.125-12.65625-28.125-28.125V146.375c0-15.46875 12.65625-28.125 28.125-28.125h506.25m0-56.25H258.875C212.1875 62 174.5 99.6875 174.5 146.375v731.25c0 46.6875 37.6875 84.375 84.375 84.375h506.25c46.6875 0 84.375-37.6875 84.375-84.375V146.375c0-46.6875-37.6875-84.375-84.375-84.375z" fill="#464F66"></path><path d="M793.25 652.625H230.75v56.25h562.5v-56.25z" fill="#464F66"></path><path d="M512 807.3125m-42.1875 0a42.1875 42.1875 0 1 0 84.375 0 42.1875 42.1875 0 1 0-84.375 0Z" fill="#F35749"></path></svg>
										<input type="text" placeholder="输入手机号码" value={this.state.account} onChange={this.accountChange} />
									</div>
								</div>
								<div className="item">
									<div>
										<svg className="icon" id="icon-code_" viewBox="0 0 1024 1024"><path d="M793.25 455.75c15.46875 0 28.125 12.65625 28.125 28.125v393.75c0 15.46875-12.65625 28.125-28.125 28.125H202.625c-15.46875 0-28.125-12.65625-28.125-28.125V483.875c0-15.46875 12.65625-28.125 28.125-28.125h590.625m0-56.25H202.625c-46.6875 0-84.375 37.6875-84.375 84.375v393.75c0 46.6875 37.6875 84.375 84.375 84.375h590.625c46.6875 0 84.375-37.6875 84.375-84.375V483.875c0-46.6875-37.6875-84.375-84.375-84.375zM238.90625 346.34375c28.6875-116.4375 133.875-203.0625 259.03125-203.0625s230.34375 86.625 259.03125 203.0625h57.9375C785.09375 198.40625 654.59375 87.03125 497.9375 87.03125S210.5 198.40625 180.96875 346.34375h57.9375z" fill="#464F66"></path><path d="M301.34375 638h85.78125v85.78125H301.34375zM455.1875 638h85.78125v85.78125h-85.78125zM608.75 638h85.78125v85.78125h-85.78125z" fill="#F35749"></path></svg>
										<input type="password" placeholder="填写您的登录密码" value={this.state.password} onChange={this.passwordChange} />
									</div>
								</div>
							</div>
							<div className="logon" onClick={this.register}>注册</div>
							<div className="tip">
								已有账号？
								<span className="font-color-red" onClick={() => { this.setState({ formItem: 1 }) }}>立即登录</span>
							</div>
						</div>
				}
			</div >
		)
	}

	accountChange = (e) => {
		this.setState({
			account: e.target.value
		})
	}

	passwordChange = (e) => {
		this.setState({
			password: e.target.value
		})
	}

	navTap(index) {
		this.setState({
			current: index
		})
	}

	submitBtn(e) {
		e.preventDefault()
	}

	loginMobile = () => {
		const { login: loginState } = this.props;
		const { account, password } = this.state

			if (!this.state.account) {
				Toast.info('请输入账号', 1.5)
				return
			} else if (this.state.account.length < 5 || this.state.account.length > 16) {
				Toast.info('账号的长度为5-16', 1.5)
				return
			}
			if (!this.state.password) {
				Toast.info('请输入登录密码', 1.5)
				return
			}

			login({ username: account, password }).then(res => {
				const token = res.data;
				loginState(token)
				this.props.history.push('/');
			}).catch(err => {
				Toast.info(err.msg, 1.5)
			})
	}

	register = () => {
		if (!this.state.account) {
			Toast.info('请输入手机号码', 1.5)
			return
		}

		if (!this.state.password) {
			Toast.info('请输入登录密码', 1.5)
			return
		}

		register({
			username: this.state.account,
			password: this.state.password
		}).then(res => {
			Toast.info(res.msg ?? "", 1.5)
			this.setState({
				formItem: 1,
				current: 0,
			})
		}).catch(err => {
			Toast.info(err.msg, 1.5)
		})
	}
}
const mapStateToProps = (state, ownProps) => {
	return {
		prop: state.prop
	}
}
const mapDispatchToProps = (dispatch, ownProps) => {
	return {
		login: (token, expires_time) => {
			dispatch({
				type: 'LOGIN',
				token: token,
				expires_time: expires_time
			})
		}
	}
}

export default connect(mapStateToProps, mapDispatchToProps)(Login)
