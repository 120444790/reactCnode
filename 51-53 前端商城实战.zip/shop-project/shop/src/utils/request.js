import * as CONFIG from '@/config';
import { Toast } from 'antd-mobile';

function baseRequest(options) {
  const url = options.url ?? '/';

  return fetch(`${CONFIG.ENDPOINT}${url.startsWith('/') ? url : `/${url}`}`, {
    method: options.method ?? 'get',
    credentials: "include",
    headers: Object.assign({
      'Content-Type': 'application/json',
    }, options.headers ?? {}),
    body: options.method === 'get' ? null : JSON.stringify(options.data),
  })
    .then(resp => resp.json())
    .then(res => {
      if (res.status === 401) {
        // 需要登录
        // 跳转登录页
        return Promise.reject({ msg: res.msg, res, data: res.data });
      }

      if (res.status === 200 || res.status === 0) {
        // 请求成功
        return Promise.resolve(res);
      }

      Toast.info(res.msg ?? "请求失败", 1.5);
      return Promise.reject({ msg: res.msg ?? "请求失败", res, data: res.data });
    });
}

const request = ["get", "post"].reduce((request, method) => {
  request[method] = (url, data = {}, options = {}) => {
    return baseRequest(Object.assign({ url, data, method }, options))
  }
  return request;
}, {});

export default request;