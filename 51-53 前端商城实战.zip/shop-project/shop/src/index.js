import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import './assets/css/index.css';
import './assets/css/reset.css';
import './assets/css/swiper.min.css';
import './assets/css/style.css';
import 'antd-mobile/dist/antd-mobile.css'
import './assets/iconfont/iconfont.css'

import App from './App';

import './utils/rem';
import { Provider } from 'react-redux';
import store from './store';

ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>,
  document.getElementById('root')
);
