import request from '@/utils/request';

export const login = (data) => {
  return request.post('/api/login', data);
}

export const register = (data) => {
  return request.post('/api/register', data);
}

export const getHomeData = (data) => {
  return request.get('/api/index', data);
}