import React, { Suspense } from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Redirect,
} from 'react-router-dom';

import routes from '@/config/router';
import { connect } from 'react-redux';

function App(props) {
  const token = props.token;
  return (
    <Suspense fallback={<div>loading...</div>}>
      <Router>
        <Switch>
          {
            routes.map((route, index) => {
              return (
                <Route
                  exact={!!route.exact}
                  key={index}
                  path={route.path}
                  render={(renderHistory) => {
                    const RouteComponent = route.component;
                    // 如果当前路由非必须登录 或者 存在 token 时渲染
                    if (!route.auth || token) {
                      return <RouteComponent {...renderHistory} />
                    }
                    return (
                      <Redirect to={{
                        pathname: '/login',
                        state: { from: renderHistory.location }
                      }} />
                    );
                  }}
                >
                </Route>
              );
            })
          }
        </Switch>
      </Router>
    </Suspense>
  );
}

const mapStateToProps = (state, props) => {
  return {
    token: state.token,
  };
}

export default connect(mapStateToProps)(App);
