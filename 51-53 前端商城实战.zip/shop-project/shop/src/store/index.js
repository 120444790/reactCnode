import { createStore, applyMiddware } from 'redux';
import userReducer from './reducer/user';

const store = createStore(
  userReducer,
)

export default store;