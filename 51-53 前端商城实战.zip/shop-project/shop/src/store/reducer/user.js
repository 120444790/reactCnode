import Cookies from 'js-cookie';

const INIT_STATE = {
  token: Cookies.get('loginToken') ?? ""
};

export default (state = INIT_STATE, action = {}) => {
  if (action.type === 'LOGIN') {
    Cookies.set('loginToken', action.token);
    return {
      ...state,
      token: action.token
    };
  }
  return state;
}