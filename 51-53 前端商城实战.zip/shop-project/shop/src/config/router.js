import React from 'react';

const routes = [
  {
    name: '/',
    path: '/',
    exact: true,
    isTab: true,
    auth: true,
    meta: {
      title: "首页",
      background: "#fff"
    },
    component: React.lazy(() => import('@/pages/index'))
  },
  {
    name: 'Login',
    path: '/login',
    exact: true,
    auth: false,
    meta: {
      title: "登录",
      background: "#fff"
    },
    component: React.lazy(() => import('@/pages/login'))
  },
];

export default routes;