const path = require('path');

const { override, fixBabelImports, addDecoratorsLegacy, addLessLoader, addWebpackAlias } = require('customize-cra');

module.exports = override(
  fixBabelImports('import', {
    libraryName: 'antd-mobile',
    style: 'css',
  }),
  addDecoratorsLegacy(),
  addLessLoader(),
  addWebpackAlias({
    '@': path.join(__dirname, 'src'),
  }),
);
