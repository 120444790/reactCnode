const Sequelize = require('sequelize');

const UserModel = require('./User');
const ShopModel = require('./shop');

const sequelize = new Sequelize('zw-shop', 'root', 'haohaoxuexi', {
  host: 'localhost',
  dialect: 'mysql'
});

const user = UserModel(sequelize, Sequelize.DataTypes);
const shop = ShopModel(sequelize, Sequelize.DataTypes);

module.exports = {
  user,
  shop,
};
